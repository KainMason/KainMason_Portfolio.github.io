# Travlr — Module 6

See API under `/api/trips` and admin SPA in `admin-spa/`.